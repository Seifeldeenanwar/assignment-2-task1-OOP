#include <iostream>
#include"bits/stdc++.h"
#include <fstream>
#include <cstdlib>
#include <ctime>
using namespace std;

class universe {
private:
    int rw, col;
    char** arr;

public:
    universe(int rw, int col)  {
        this->rw = rw;
        this->col = col;
        arr = new char*[rw];
        for (int i = 0; i < rw; i++) {
            arr[i] = new char[col];
        }
    }
    ~universe() {
        for (int i = 0; i < rw; i++) {
            delete[] arr[i];
        }
        delete[] arr;
    }
    void reset() {
        for (int i = 0; i < rw; i++) {
            for (int j = 0; j < col; j++) {
                arr[i][j] = 'D';
            }
        }
    }
    void initialize(int num_cells)
    {
        int c, r;
        srand(time(nullptr));
        while (num_cells > 0) {
            r = rand() % rw  ;
            c = rand() % col ;
            if (r >= 0 && r < rw && c >= 0 && c < col){
                arr[r][c] = 'L';
                num_cells--;
            }
        }
    }

    int count_neighbors(int r, int c){ // counting number of neighbors  
        int cont = 0;

        if (r > 0 && c > 0 && arr[r - 1][c - 1] == 'L') cont++;  // Top-left
        if (r > 0 && arr[r - 1][c] == 'L') cont++;                  // Top
        if (r > 0 && c < col - 1 && arr[r - 1][c + 1] == 'L') cont++;  // Top-right
        if (c > 0 && arr[r][c - 1] == 'L') cont++;                  // Left
        if (c < col - 1 && arr[r][c + 1] == 'L') cont++;              // Right
        if (r < rw - 1 && c > 0 && arr[r + 1][c - 1] == 'L') cont++;  // Bottom-left
        if (r < rw - 1 && arr[r + 1][c] == 'L') cont++;              // Bottom
        if (r < rw - 1 && c < col - 1 && arr[r + 1][c + 1] == 'L') cont++;  // Bottom-right

        return cont;
    }

    void next_generation(){ // here i put the conditions to still a cell living or die 

        char** new_arr = new char*[rw]; //creat new array of pointer 
        for (int i = 0; i < rw; i++){
            new_arr[i] = new char[col];
        }
        for (int i = 0; i < rw; i++){
            for (int j = 0; j < col; j++){
                int live_neighbors = count_neighbors(i, j);

                if (arr[i][j] == 'L'){
                    if (live_neighbors < 2 || live_neighbors > 3){
                        new_arr[i][j] = 'D';
                    }
                    else{
                        new_arr[i][j] = 'L';
                    }
                }
                else if (arr[i][j] == 'D' && live_neighbors == 3){
                    new_arr[i][j] = 'L';
                }
                else{
                    new_arr[i][j] = 'D';
                }
            }
        }
        for (int i = 0; i < rw; i++){ //make a new_arr = arr which is the attribute of class universe
        
            for (int j = 0; j < col; j++){
                arr[i][j] = new_arr[i][j];
            }
        }
        for (int i = 0; i < rw; i++){ // delete array of pointers to not distroy memory 
            delete[] new_arr[i];
        }
        delete[] new_arr;
    }

    void display(){
        for (int i = 0; i < rw; i++){
            for (int j = 0; j < col; j++){
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
    }
    void run(int num_runs){
        for (int run = 1; run <= num_runs; run++){
            cout << "\nGeneration " << run << ":" << endl;
            display();
            next_generation();
        }
    }
    friend void accss_array(const universe& U,int row , int column , char c) ; // to accss that private array of pointer
};

void accss_array(const universe& U , int row , int column , char c){
     U.arr[row][column] = c ;
}
string file_valid(){
     string file_name ;
     cout << "Enter file name (Fixed size of game 20*20) -> " ;
     while(true){
     cin >> file_name ;
     ifstream file(file_name) ;
     if(file){return file_name ;}
     else{cout << "invalid file name , enter a valid one -> " ;}
     }
}
universe file_option(){
     string file_name = file_valid() ;
     universe U(20,20) ;
     ifstream file(file_name) ;
     string line1  ;
     string line2 = "";
     int i = 0 ;
     while(!file.eof()){   
     getline(file,line1) ; 
     for(char c : line1){
        if(c == 'L' || c == 'D'){
            line2 += c ;
        }
     }
     for(int j = 0 ; j < 20 ; j++){
        accss_array(U,i,j,line2[j]) ;
     }
     line2 = "" ;
     i++;
}
return U ;
}
int InputDefence(){
    int dim ;
    while(true){
        cin >> dim ;
         if (cin.fail()){
            cin.clear() ;
            string badInput;
            getline(cin, badInput);  // I have searched for this method
            cout << "Error enter a valid input -> " ;
        }
        else {
            return abs(dim) ; // ignore -ve sign 
        }
    }
}
universe menu_manual() {
    int row, column ;
    cout << "Enter size of game (row * column) -> " ;
    row = InputDefence() ;
    column = InputDefence() ;
    int num_intial = (row*column)*(0.3) ;
    universe u(row,column);
    u.reset();
    u.initialize(num_intial);
    return u ;
}
void MENU(){
char choice ;
cout << "\nWelcome to game of life :>" << endl ;
cout << "Formate of this game D -> die L -> live " << endl; 
cout << "Fixed percentage of living cells is 30% " << endl; 
while(true){
cout << "\nChoose the method of starting the game: \n1-Ordinary method \n2-Enter a file \nElse-Exit program " << endl ;
cout << "-> " ;
cin >> choice ;
if(choice == '1'){
    int runs ;
    universe u = menu_manual() ;
    cout << "Enter number of runs -> " ;
    cin >> runs ;
    cout << endl; 
    u.run(runs) ;
}
else if (choice == '2') {
    int runs ;
    universe u = file_option() ;
    cout << "Enter number of runs -> " ;
    cin >> runs ;
    cout << endl; 
    u.run(runs) ;
}
else {
    cout << "End program !" << endl;
    break ;
   }
 }
}
int main()
{
    MENU() ;
    return 0;
}
